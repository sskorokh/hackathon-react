<div className = 'general-border center'>

           <Button type=“submit” className="text-uppercase  btn-outline-
                                       danger gap" variant='none'>  add/update
            </Button>

            <Button type=“reset”  className="text-uppercase  btn-outline-
                                      warning" variant='none’ > clear
            </Button>
          
      </div>
